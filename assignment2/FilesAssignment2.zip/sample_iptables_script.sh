#!/bin/bash
#BIOchem's new firewall

#IP-addresses
fw_eth1="10.10.1.1"
fw_eth0="10.10.2.1"
workstation_net="10.10.1.0/24"
server_net="10.10.2.0/24"
mail_srv=...

#Default policies
...

#Specific rules
...

